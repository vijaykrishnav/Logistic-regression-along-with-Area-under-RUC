

```python
#getting libraries
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as mlt
%matplotlib inline
```


```python
#getting file
crd1=pd.read_csv('D:\\V data analytics\\sample dataset\\Dataset by Imarticus\\Data for logistic regression\\R_Module_Day_7.2_Credit_Risk_Train_data.csv')
crd2=pd.read_csv('D:\\V data analytics\\sample dataset\\Dataset by Imarticus\\Data for logistic regression\\R_Module_Day_8.2_Credit_Risk_Validate_data.csv')
```


```python
# to do missing value imputation, we will concat both train and validation data

crd=pd.concat([crd1,crd2],axis=0)
```


```python
crd.isna().sum()
```




    Loan_ID               0
    Gender               24
    Married               3
    Dependents           25
    Education             0
    Self_Employed        55
    ApplicantIncome       0
    CoapplicantIncome     0
    LoanAmount           27
    Loan_Amount_Term     20
    Credit_History       79
    Property_Area         0
    Loan_Status           0
    dtype: int64




```python
#lets reset index just to be sure
crd.reset_index(inplace=True,drop=True)
```


```python
crd.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Loan_ID</th>
      <th>Gender</th>
      <th>Married</th>
      <th>Dependents</th>
      <th>Education</th>
      <th>Self_Employed</th>
      <th>ApplicantIncome</th>
      <th>CoapplicantIncome</th>
      <th>LoanAmount</th>
      <th>Loan_Amount_Term</th>
      <th>Credit_History</th>
      <th>Property_Area</th>
      <th>Loan_Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>LP001002</td>
      <td>Male</td>
      <td>No</td>
      <td>0</td>
      <td>Graduate</td>
      <td>No</td>
      <td>5849</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>1</th>
      <td>LP001003</td>
      <td>Male</td>
      <td>Yes</td>
      <td>1</td>
      <td>Graduate</td>
      <td>No</td>
      <td>4583</td>
      <td>1508.0</td>
      <td>128.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Rural</td>
      <td>N</td>
    </tr>
    <tr>
      <th>2</th>
      <td>LP001005</td>
      <td>Male</td>
      <td>Yes</td>
      <td>0</td>
      <td>Graduate</td>
      <td>Yes</td>
      <td>3000</td>
      <td>0.0</td>
      <td>66.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>3</th>
      <td>LP001006</td>
      <td>Male</td>
      <td>Yes</td>
      <td>0</td>
      <td>Not Graduate</td>
      <td>No</td>
      <td>2583</td>
      <td>2358.0</td>
      <td>120.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>4</th>
      <td>LP001008</td>
      <td>Male</td>
      <td>No</td>
      <td>0</td>
      <td>Graduate</td>
      <td>No</td>
      <td>6000</td>
      <td>0.0</td>
      <td>141.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
  </tbody>
</table>
</div>




```python
#all good lets check for missing values
crd.isna().sum()
```




    Loan_ID               0
    Gender               24
    Married               3
    Dependents           25
    Education             0
    Self_Employed        55
    ApplicantIncome       0
    CoapplicantIncome     0
    LoanAmount           27
    Loan_Amount_Term     20
    Credit_History       79
    Property_Area         0
    Loan_Status           0
    dtype: int64




```python
#missing value of imputation, to get the list of indices of gender missing values we do
genmiss=crd[crd['Gender'].isna()].index.tolist()
```


```python
#to find out the mode we do,
crd.Gender.value_counts()
```




    Male      775
    Female    182
    Name: Gender, dtype: int64




```python
#lets fill up missing value by 'Male'
crd['Gender'].iloc[genmiss]='Male'
```


```python
crd.Gender.isna().sum()
```




    0




```python
#great, lets do the missing value imputation for married
crd.Married.value_counts()
```




    Yes    631
    No     347
    Name: Married, dtype: int64




```python
#lets fill up nas by 'Yes'
crd['Married'].iloc[crd[crd['Married'].isna()].index.tolist()]='Yes'
```


```python
crd.Married.isna().sum()
```




    0




```python
#lets do missing value impputation of dependents
crd.Dependents.value_counts()
```




    0     545
    2     160
    1     160
    3+     91
    Name: Dependents, dtype: int64




```python
crd.Dependents.isna().sum()
```




    16




```python
#lets fill the nas of dependents missing value in case of not married people as zero
# so we need the dataframe where married is no and dependents is na
dmiss1=crd[(crd['Married']=='No') & (crd['Dependents'].isna())].index.tolist()
print(dmiss1)
```

    []
    


```python
#filling it up with zero
crd['Dependents'].iloc[dmiss1]='0'
```


```python
crd.Dependents.value_counts()
```




    0     554
    2     160
    1     160
    3+     91
    Name: Dependents, dtype: int64




```python
crd.Dependents.isna().sum()
```




    16




```python
#lets do a crosstab of gender with dependents
pd.crosstab(crd['Gender'],crd['Dependents'].isna())  # out of 16, 15 values corresponds to male
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Dependents</th>
      <th>False</th>
      <th>True</th>
    </tr>
    <tr>
      <th>Gender</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Female</th>
      <td>181</td>
      <td>1</td>
    </tr>
    <tr>
      <th>Male</th>
      <td>784</td>
      <td>15</td>
    </tr>
  </tbody>
</table>
</div>




```python
#lets do the cross tab of dependents and gender
pd.crosstab(crd['Gender'],crd['Dependents'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Dependents</th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3+</th>
    </tr>
    <tr>
      <th>Gender</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Female</th>
      <td>127</td>
      <td>32</td>
      <td>13</td>
      <td>9</td>
    </tr>
    <tr>
      <th>Male</th>
      <td>427</td>
      <td>128</td>
      <td>147</td>
      <td>82</td>
    </tr>
  </tbody>
</table>
</div>




```python
#since most of male have a mode of 0, lets fill the remaining values by 0
crd['Dependents'][(crd['Dependents'].isna())]='0'
```

    C:\ProgramData\Anaconda\lib\site-packages\ipykernel_launcher.py:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      
    


```python
crd.Dependents.isna().sum()
```




    0




```python
#missing value impution of selfemployed
crd.Self_Employed.isna().sum()
```




    55




```python
crd.Self_Employed.value_counts()
```




    No     807
    Yes    119
    Name: Self_Employed, dtype: int64




```python
#replacing nas with 'No'
crd['Self_Employed'].iloc[crd[crd['Self_Employed'].isna()].index.tolist()]='No'
```


```python
#mvi of loanamount loanamount_term
#lets compare the missingvalues of loanamount with loanamountterm
pd.crosstab(crd['Loan_Amount_Term'],crd['LoanAmount'].isna())
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>LoanAmount</th>
      <th>False</th>
      <th>True</th>
    </tr>
    <tr>
      <th>Loan_Amount_Term</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>6.0</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>12.0</th>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>36.0</th>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>60.0</th>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>84.0</th>
      <td>7</td>
      <td>0</td>
    </tr>
    <tr>
      <th>120.0</th>
      <td>4</td>
      <td>0</td>
    </tr>
    <tr>
      <th>180.0</th>
      <td>64</td>
      <td>2</td>
    </tr>
    <tr>
      <th>240.0</th>
      <td>7</td>
      <td>1</td>
    </tr>
    <tr>
      <th>300.0</th>
      <td>20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>350.0</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>360.0</th>
      <td>800</td>
      <td>23</td>
    </tr>
    <tr>
      <th>480.0</th>
      <td>22</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
#its evident that loan_amount_term pertaining to 360 has highest numbers of nas.
# we will fill the value by the mean of the loanamount corresponding to the loan_amount_term 360.
crd.groupby(crd['Loan_Amount_Term'])['LoanAmount'].mean()
```




    Loan_Amount_Term
    6.0       95.000000
    12.0     185.500000
    36.0     117.666667
    60.0     139.666667
    84.0     121.142857
    120.0     36.750000
    180.0    131.125000
    240.0    128.857143
    300.0    166.250000
    350.0    133.000000
    360.0    144.420000
    480.0    137.181818
    Name: LoanAmount, dtype: float64




```python
# lets fill the loanampunt na's in the range of 360 by 144
crd['LoanAmount'].iloc[crd[(crd['Loan_Amount_Term']==360) & (crd['LoanAmount'].isna())].index.tolist()]=144
```


```python
#for the rest of nas lets replace the values by 132
crd['LoanAmount'].iloc[crd[crd['LoanAmount'].isna()].index.tolist()]=132
```


```python
#missing value imputation of loan_amount_term
crd.Loan_Amount_Term.isnull().sum()
```




    20




```python
crd.Loan_Amount_Term.value_counts()
```




    360.0    823
    180.0     66
    480.0     23
    300.0     20
    240.0      8
    84.0       7
    120.0      4
    36.0       3
    60.0       3
    12.0       2
    350.0      1
    6.0        1
    Name: Loan_Amount_Term, dtype: int64




```python
#lets fill up by mode, ie 360
crd['Loan_Amount_Term'].iloc[crd[crd['Loan_Amount_Term'].isna()].index.tolist()]=360
```


```python
#missing value imutation of Credit_history by Logistic regression

crd.Credit_History.isnull().sum()
```




    79




```python
#lets separate the dataframe as train and test, lets take all na's in credithistory as test data
crd_testdata=crd.loc[crd['Credit_History'].isna(),:]
```


```python
#to get traindata, we will first get incex of all na's of credithistory
crd_credna_indx=crd[crd['Credit_History'].isna()].index.tolist()
```


```python
#getting traindata
crd_traindata_index=[x for x in crd.index.tolist() if x not in crd_credna_indx]
```


```python
crd_traindata=crd.iloc[crd_traindata_index]
```


```python
#Tp do a logistic regression, we will lose all unimo variables and get dummies for all catagorical variables
crd_train1=pd.get_dummies(crd_traindata.drop(['Loan_ID'],axis=1),drop_first=True)
```


```python
crd_train1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ApplicantIncome</th>
      <th>CoapplicantIncome</th>
      <th>LoanAmount</th>
      <th>Loan_Amount_Term</th>
      <th>Credit_History</th>
      <th>Gender_Male</th>
      <th>Married_Yes</th>
      <th>Dependents_1</th>
      <th>Dependents_2</th>
      <th>Dependents_3+</th>
      <th>Education_Not Graduate</th>
      <th>Self_Employed_Yes</th>
      <th>Property_Area_Semiurban</th>
      <th>Property_Area_Urban</th>
      <th>Loan_Status_Y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5849</td>
      <td>0.0</td>
      <td>144.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4583</td>
      <td>1508.0</td>
      <td>128.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3000</td>
      <td>0.0</td>
      <td>66.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2583</td>
      <td>2358.0</td>
      <td>120.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6000</td>
      <td>0.0</td>
      <td>141.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
#lets do the same for testdata
crd_test1=pd.get_dummies(crd_testdata.drop(['Loan_ID'],axis=1),drop_first=True)
```


```python
crd_test1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ApplicantIncome</th>
      <th>CoapplicantIncome</th>
      <th>LoanAmount</th>
      <th>Loan_Amount_Term</th>
      <th>Credit_History</th>
      <th>Gender_Male</th>
      <th>Married_Yes</th>
      <th>Dependents_1</th>
      <th>Dependents_2</th>
      <th>Dependents_3+</th>
      <th>Education_Not Graduate</th>
      <th>Self_Employed_Yes</th>
      <th>Property_Area_Semiurban</th>
      <th>Property_Area_Urban</th>
      <th>Loan_Status_Y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>16</th>
      <td>3596</td>
      <td>0.0</td>
      <td>100.0</td>
      <td>240.0</td>
      <td>NaN</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>24</th>
      <td>3717</td>
      <td>2925.0</td>
      <td>151.0</td>
      <td>360.0</td>
      <td>NaN</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>30</th>
      <td>4166</td>
      <td>3369.0</td>
      <td>201.0</td>
      <td>360.0</td>
      <td>NaN</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>42</th>
      <td>2400</td>
      <td>0.0</td>
      <td>75.0</td>
      <td>360.0</td>
      <td>NaN</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>79</th>
      <td>3333</td>
      <td>2166.0</td>
      <td>130.0</td>
      <td>360.0</td>
      <td>NaN</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
#preparing xtrain and y train, xtest and ytest
x_train1=crd_train1.drop(['Credit_History','Loan_Status_Y'],axis=1)
y_train1=crd_train1['Credit_History']
```


```python
#similarly for test set
x_test1=crd_test1.drop(['Credit_History','Loan_Status_Y'],axis=1)
y_test1=crd_test1['Credit_History']
```


```python
from sklearn.linear_model import LogisticRegression
```


```python
m1=LogisticRegression()
```


```python
m1.fit(x_train1,y_train1)
```




    LogisticRegression(C=1.0, class_weight=None, dual=False, fit_intercept=True,
              intercept_scaling=1, max_iter=100, multi_class='ovr', n_jobs=1,
              penalty='l2', random_state=None, solver='liblinear', tol=0.0001,
              verbose=0, warm_start=False)




```python
#predicting for xtest
pred1=m1.predict(x_test1)
```


```python
print(pred1)
```

    [1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 1. 1. 1.]
    


```python
crd_test1['Credit_History']=pred1
```


```python
crd_new=pd.concat([crd_train1,crd_test1],axis=0)
```


```python
crd_new.isnull().sum()
```




    ApplicantIncome            0
    CoapplicantIncome          0
    LoanAmount                 0
    Loan_Amount_Term           0
    Credit_History             0
    Gender_Male                0
    Married_Yes                0
    Dependents_1               0
    Dependents_2               0
    Dependents_3+              0
    Education_Not Graduate     0
    Self_Employed_Yes          0
    Property_Area_Semiurban    0
    Property_Area_Urban        0
    Loan_Status_Y              0
    dtype: int64




```python
crd_new.shape
```




    (981, 15)




```python
crd.Credit_History.isna().sum()
```




    79




```python
crd['Credit_History'].iloc[crd[crd['Credit_History'].isna()].index.tolist()]=pred1
```


```python
crd.isnull().sum()
```




    Loan_ID              0
    Gender               0
    Married              0
    Dependents           0
    Education            0
    Self_Employed        0
    ApplicantIncome      0
    CoapplicantIncome    0
    LoanAmount           0
    Loan_Amount_Term     0
    Credit_History       0
    Property_Area        0
    Loan_Status          0
    dtype: int64




```python
crd.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Loan_ID</th>
      <th>Gender</th>
      <th>Married</th>
      <th>Dependents</th>
      <th>Education</th>
      <th>Self_Employed</th>
      <th>ApplicantIncome</th>
      <th>CoapplicantIncome</th>
      <th>LoanAmount</th>
      <th>Loan_Amount_Term</th>
      <th>Credit_History</th>
      <th>Property_Area</th>
      <th>Loan_Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>LP001002</td>
      <td>Male</td>
      <td>No</td>
      <td>0</td>
      <td>Graduate</td>
      <td>No</td>
      <td>5849</td>
      <td>0.0</td>
      <td>144.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>1</th>
      <td>LP001003</td>
      <td>Male</td>
      <td>Yes</td>
      <td>1</td>
      <td>Graduate</td>
      <td>No</td>
      <td>4583</td>
      <td>1508.0</td>
      <td>128.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Rural</td>
      <td>N</td>
    </tr>
    <tr>
      <th>2</th>
      <td>LP001005</td>
      <td>Male</td>
      <td>Yes</td>
      <td>0</td>
      <td>Graduate</td>
      <td>Yes</td>
      <td>3000</td>
      <td>0.0</td>
      <td>66.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>3</th>
      <td>LP001006</td>
      <td>Male</td>
      <td>Yes</td>
      <td>0</td>
      <td>Not Graduate</td>
      <td>No</td>
      <td>2583</td>
      <td>2358.0</td>
      <td>120.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>4</th>
      <td>LP001008</td>
      <td>Male</td>
      <td>No</td>
      <td>0</td>
      <td>Graduate</td>
      <td>No</td>
      <td>6000</td>
      <td>0.0</td>
      <td>141.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
  </tbody>
</table>
</div>




```python
# lets go ahead woth logistic regression now
```


```python
#some basic eda's first
sns.barplot(x=crd['Loan_Status'],y=crd['LoanAmount'],hue=crd['Gender'],data=crd)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x11261048>




![png](output_59_1.png)



```python
sns.barplot(x=crd['Credit_History'],y=crd['Loan_Status'],hue=crd['Married'],data=crd)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1159b390>




![png](output_60_1.png)



```python
sns.barplot(x=crd['Loan_Status'],y=crd['ApplicantIncome'],hue=crd['Property_Area'],data=crd) #(so rural property got rejected most)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x12967898>




![png](output_61_1.png)



```python
sns.barplot(x=crd['Loan_Status'],y=crd['ApplicantIncome'],hue=crd['Dependents'],data=crd) #interesting fact is applicant with..
#..3+ dependents were rejected also were given higher no of loans!!
```




    <matplotlib.axes._subplots.AxesSubplot at 0x124292b0>




![png](output_62_1.png)



```python
# lets split the data into train and validation,just like how it was given previously
```


```python
crd_train=crd.head(len(crd1))
```


```python
crd_train.to_csv('D:\\V data analytics\\sample dataset\\Dataset by Imarticus\\Data for logistic regression\\Loan_eligibility_estimation_traindata_withmv_imputed\\crd_train.csv')
```


```python
crd_val=crd.tail(len(crd2))
```


```python
crd_val.to_csv('D:\\V data analytics\\sample dataset\\Dataset by Imarticus\\Data for logistic regression\\Loan_eligibility_estimation_train _test_data_withmv_imputed\\crd_val.csv')
```

### Logistic regression with area under roc curve


```python
#getting dummies for all catagorical variables
crd.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 981 entries, 0 to 980
    Data columns (total 13 columns):
    Loan_ID              981 non-null object
    Gender               981 non-null object
    Married              981 non-null object
    Dependents           981 non-null object
    Education            981 non-null object
    Self_Employed        981 non-null object
    ApplicantIncome      981 non-null int64
    CoapplicantIncome    981 non-null float64
    LoanAmount           981 non-null float64
    Loan_Amount_Term     981 non-null float64
    Credit_History       981 non-null float64
    Property_Area        981 non-null object
    Loan_Status          981 non-null object
    dtypes: float64(4), int64(1), object(8)
    memory usage: 99.7+ KB
    


```python
#seperating dvb
crd_new1=pd.get_dummies(crd.drop(['Loan_ID','Loan_Status'],axis=1),drop_first=True)
```


```python
crd_new1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ApplicantIncome</th>
      <th>CoapplicantIncome</th>
      <th>LoanAmount</th>
      <th>Loan_Amount_Term</th>
      <th>Credit_History</th>
      <th>Gender_Male</th>
      <th>Married_Yes</th>
      <th>Dependents_1</th>
      <th>Dependents_2</th>
      <th>Dependents_3+</th>
      <th>Education_Not Graduate</th>
      <th>Self_Employed_Yes</th>
      <th>Property_Area_Semiurban</th>
      <th>Property_Area_Urban</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5849</td>
      <td>0.0</td>
      <td>144.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4583</td>
      <td>1508.0</td>
      <td>128.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3000</td>
      <td>0.0</td>
      <td>66.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2583</td>
      <td>2358.0</td>
      <td>120.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6000</td>
      <td>0.0</td>
      <td>141.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
x_train=crd_new1
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-2-4f537bfe5712> in <module>()
    ----> 1 x_train=crd_new1
    

    NameError: name 'crd_new1' is not defined



```python
y_train=crd['Loan_Status']
```


```python
m2=LogisticRegression()
```


```python
m2.fit(x_train,y_train)
```




    LogisticRegression(C=1.0, class_weight=None, dual=False, fit_intercept=True,
              intercept_scaling=1, max_iter=100, multi_class='ovr', n_jobs=1,
              penalty='l2', random_state=None, solver='liblinear', tol=0.0001,
              verbose=0, warm_start=False)




```python
m2.score(x_train,y_train) 
```




    0.8562691131498471




```python
# PREDICTING DATA FOR VALIDATION DATA
crd_val.shape
```




    (367, 13)




```python
crd_val.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Loan_ID</th>
      <th>Gender</th>
      <th>Married</th>
      <th>Dependents</th>
      <th>Education</th>
      <th>Self_Employed</th>
      <th>ApplicantIncome</th>
      <th>CoapplicantIncome</th>
      <th>LoanAmount</th>
      <th>Loan_Amount_Term</th>
      <th>Credit_History</th>
      <th>Property_Area</th>
      <th>Loan_Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>614</th>
      <td>LP001015</td>
      <td>Male</td>
      <td>Yes</td>
      <td>0</td>
      <td>Graduate</td>
      <td>No</td>
      <td>5720</td>
      <td>0.0</td>
      <td>110.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>615</th>
      <td>LP001022</td>
      <td>Male</td>
      <td>Yes</td>
      <td>1</td>
      <td>Graduate</td>
      <td>No</td>
      <td>3076</td>
      <td>1500.0</td>
      <td>126.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>616</th>
      <td>LP001031</td>
      <td>Male</td>
      <td>Yes</td>
      <td>2</td>
      <td>Graduate</td>
      <td>No</td>
      <td>5000</td>
      <td>1800.0</td>
      <td>208.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>617</th>
      <td>LP001035</td>
      <td>Male</td>
      <td>Yes</td>
      <td>2</td>
      <td>Graduate</td>
      <td>No</td>
      <td>2340</td>
      <td>2546.0</td>
      <td>100.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>618</th>
      <td>LP001051</td>
      <td>Male</td>
      <td>No</td>
      <td>0</td>
      <td>Not Graduate</td>
      <td>No</td>
      <td>3276</td>
      <td>0.0</td>
      <td>78.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>N</td>
    </tr>
  </tbody>
</table>
</div>




```python
#preparing data to predict
crd_val1=crd_val.drop(['Loan_ID','Loan_Status'],axis=1)
```


```python
#getting dummyvalues for cvs
crdval=pd.get_dummies(crd_val1,drop_first=True)
```


```python
crdval.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ApplicantIncome</th>
      <th>CoapplicantIncome</th>
      <th>LoanAmount</th>
      <th>Loan_Amount_Term</th>
      <th>Credit_History</th>
      <th>Gender_Male</th>
      <th>Married_Yes</th>
      <th>Dependents_1</th>
      <th>Dependents_2</th>
      <th>Dependents_3+</th>
      <th>Education_Not Graduate</th>
      <th>Self_Employed_Yes</th>
      <th>Property_Area_Semiurban</th>
      <th>Property_Area_Urban</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>614</th>
      <td>5720</td>
      <td>0.0</td>
      <td>110.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>615</th>
      <td>3076</td>
      <td>1500.0</td>
      <td>126.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>616</th>
      <td>5000</td>
      <td>1800.0</td>
      <td>208.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>617</th>
      <td>2340</td>
      <td>2546.0</td>
      <td>100.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>618</th>
      <td>3276</td>
      <td>0.0</td>
      <td>78.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
#predicting
pred2=m2.predict(crdval)
```


```python
#getting crosstab
pd.crosstab(crd_val['Loan_Status'],pred2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>col_0</th>
      <th>N</th>
      <th>Y</th>
    </tr>
    <tr>
      <th>Loan_Status</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>N</th>
      <td>55</td>
      <td>22</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>1</td>
      <td>289</td>
    </tr>
  </tbody>
</table>
</div>




```python
#to get crosstab we download metrics
from sklearn import metrics
```


```python
metrics.confusion_matrix(crd_val['Loan_Status'],pred2) #we can interpret the results as predicted
                                                                                #       N      Y
                                                  #          actual loanstatus  N      55      22
                                                  #                             Y      1       289
```




    array([[ 55,  22],
           [  1, 289]], dtype=int64)




```python
#sensitivity of the model =tp/tp+fn= 289/289+1=99% highly sensitive
#speificity of the model = tn/tn+fp=55/55+22=55/77= 71% speific
```


```python
#lets get the valuecount of loanstatus in validation data
crd_val.Loan_Status.value_counts()
```




    Y    290
    N     77
    Name: Loan_Status, dtype: int64




```python
#accuracy score
metrics.accuracy_score(crd_val['Loan_Status'],pred2) #93% great 
```




    0.9373297002724795




```python
crd_val.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Loan_ID</th>
      <th>Gender</th>
      <th>Married</th>
      <th>Dependents</th>
      <th>Education</th>
      <th>Self_Employed</th>
      <th>ApplicantIncome</th>
      <th>CoapplicantIncome</th>
      <th>LoanAmount</th>
      <th>Loan_Amount_Term</th>
      <th>Credit_History</th>
      <th>Property_Area</th>
      <th>Loan_Status</th>
      <th>Loan_Status_digit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>614</th>
      <td>LP001015</td>
      <td>Male</td>
      <td>Yes</td>
      <td>0</td>
      <td>Graduate</td>
      <td>No</td>
      <td>5720</td>
      <td>0.0</td>
      <td>110.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
      <td>1</td>
    </tr>
    <tr>
      <th>615</th>
      <td>LP001022</td>
      <td>Male</td>
      <td>Yes</td>
      <td>1</td>
      <td>Graduate</td>
      <td>No</td>
      <td>3076</td>
      <td>1500.0</td>
      <td>126.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
      <td>1</td>
    </tr>
    <tr>
      <th>616</th>
      <td>LP001031</td>
      <td>Male</td>
      <td>Yes</td>
      <td>2</td>
      <td>Graduate</td>
      <td>No</td>
      <td>5000</td>
      <td>1800.0</td>
      <td>208.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
      <td>1</td>
    </tr>
    <tr>
      <th>617</th>
      <td>LP001035</td>
      <td>Male</td>
      <td>Yes</td>
      <td>2</td>
      <td>Graduate</td>
      <td>No</td>
      <td>2340</td>
      <td>2546.0</td>
      <td>100.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>Y</td>
      <td>1</td>
    </tr>
    <tr>
      <th>618</th>
      <td>LP001051</td>
      <td>Male</td>
      <td>No</td>
      <td>0</td>
      <td>Not Graduate</td>
      <td>No</td>
      <td>3276</td>
      <td>0.0</td>
      <td>78.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>Urban</td>
      <td>N</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
crdval.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ApplicantIncome</th>
      <th>CoapplicantIncome</th>
      <th>LoanAmount</th>
      <th>Loan_Amount_Term</th>
      <th>Credit_History</th>
      <th>Gender_Male</th>
      <th>Married_Yes</th>
      <th>Dependents_1</th>
      <th>Dependents_2</th>
      <th>Dependents_3+</th>
      <th>Education_Not Graduate</th>
      <th>Self_Employed_Yes</th>
      <th>Property_Area_Semiurban</th>
      <th>Property_Area_Urban</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>614</th>
      <td>5720</td>
      <td>0.0</td>
      <td>110.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>615</th>
      <td>3076</td>
      <td>1500.0</td>
      <td>126.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>616</th>
      <td>5000</td>
      <td>1800.0</td>
      <td>208.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>617</th>
      <td>2340</td>
      <td>2546.0</td>
      <td>100.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>618</th>
      <td>3276</td>
      <td>0.0</td>
      <td>78.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
crdval['Loan_Status']=crd_val['Loan_Status'] #in crdval, we add loanstatus, since we have to conver it to digits by mapping
```


```python
crdval.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ApplicantIncome</th>
      <th>CoapplicantIncome</th>
      <th>LoanAmount</th>
      <th>Loan_Amount_Term</th>
      <th>Credit_History</th>
      <th>Gender_Male</th>
      <th>Married_Yes</th>
      <th>Dependents_1</th>
      <th>Dependents_2</th>
      <th>Dependents_3+</th>
      <th>Education_Not Graduate</th>
      <th>Self_Employed_Yes</th>
      <th>Property_Area_Semiurban</th>
      <th>Property_Area_Urban</th>
      <th>Loan_Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>614</th>
      <td>5720</td>
      <td>0.0</td>
      <td>110.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>615</th>
      <td>3076</td>
      <td>1500.0</td>
      <td>126.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>616</th>
      <td>5000</td>
      <td>1800.0</td>
      <td>208.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>617</th>
      <td>2340</td>
      <td>2546.0</td>
      <td>100.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>618</th>
      <td>3276</td>
      <td>0.0</td>
      <td>78.0</td>
      <td>360.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>N</td>
    </tr>
  </tbody>
</table>
</div>




```python
crdval['Loan_Status_digit']=crdval.Loan_Status.map({'N':0,'Y':1})
```


```python
crdval1=crdval.drop(['Loan_Status'],axis=1)
```


```python
crdval1.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 367 entries, 614 to 980
    Data columns (total 15 columns):
    ApplicantIncome            367 non-null int64
    CoapplicantIncome          367 non-null float64
    LoanAmount                 367 non-null float64
    Loan_Amount_Term           367 non-null float64
    Credit_History             367 non-null float64
    Gender_Male                367 non-null uint8
    Married_Yes                367 non-null uint8
    Dependents_1               367 non-null uint8
    Dependents_2               367 non-null uint8
    Dependents_3+              367 non-null uint8
    Education_Not Graduate     367 non-null uint8
    Self_Employed_Yes          367 non-null uint8
    Property_Area_Semiurban    367 non-null uint8
    Property_Area_Urban        367 non-null uint8
    Loan_Status_digit          367 non-null int64
    dtypes: float64(4), int64(2), uint8(9)
    memory usage: 20.5 KB
    


```python
crdval.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 367 entries, 614 to 980
    Data columns (total 16 columns):
    ApplicantIncome            367 non-null int64
    CoapplicantIncome          367 non-null float64
    LoanAmount                 367 non-null float64
    Loan_Amount_Term           367 non-null float64
    Credit_History             367 non-null float64
    Gender_Male                367 non-null uint8
    Married_Yes                367 non-null uint8
    Dependents_1               367 non-null uint8
    Dependents_2               367 non-null uint8
    Dependents_3+              367 non-null uint8
    Education_Not Graduate     367 non-null uint8
    Self_Employed_Yes          367 non-null uint8
    Property_Area_Semiurban    367 non-null uint8
    Property_Area_Urban        367 non-null uint8
    Loan_Status                367 non-null object
    Loan_Status_digit          367 non-null int64
    dtypes: float64(4), int64(2), object(1), uint8(9)
    memory usage: 23.4+ KB
    


```python
probvalues_of_dv=m2.predict_proba(crdval1.drop(['Loan_Status_digit'],axis=1))
```


```python
Loan_status_prob0=m2.predict_proba(crdval1.drop(['Loan_Status_digit'],axis=1))[:,1]
```


```python
#graph
sns.distplot(Loan_status_prob0,kde=False,bins=50)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x135445f8>




![png](output_99_1.png)



```python
#roc curve
fpr,tpr,thresholds=metrics.roc_curve(crd_val['Loan_Status_digit'],Loan_status_prob0)
```


```python
mlt.plot(fpr,tpr)
```




    [<matplotlib.lines.Line2D at 0x13941240>]




![png](output_101_1.png)



```python
#getting area under aoc
metrics.roc_auc_score(crd_val['Loan_Status_digit'],Loan_status_prob0)
```




    0.9467532467532468


